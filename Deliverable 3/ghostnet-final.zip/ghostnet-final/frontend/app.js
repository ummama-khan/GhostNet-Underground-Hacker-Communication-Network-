// ============================================================
//  GHOSTNET V2 — DEBUG VERSION
// ============================================================

const API = 'http://127.0.0.1:5000';

let authToken    = null;
let currentUser  = null;
let currentRole  = null;
let currentCell  = 'cell_alpha';
let pollTimer    = null;
let selectedRole = null;

function utcNow() { return Math.floor(Date.now() / 1000); }

function showLogin() {
    document.getElementById('landing-content').classList.add('hidden');
    document.getElementById('login-overlay').classList.remove('hidden');
    document.getElementById('username').focus();
}

function hideLogin() {
    document.getElementById('login-overlay').classList.add('hidden');
    document.getElementById('landing-content').classList.remove('hidden');
    clearAuthError();
}

async function login() {
    const user = document.getElementById('username').value.trim();
    const pass = document.getElementById('password').value.trim();
    if (!user || !pass) { showAuthError('CREDENTIALS REQUIRED'); return; }

    const btn = document.querySelector('.btn-login-main');
    btn.textContent = 'CONNECTING…';
    btn.disabled = true;

    try {
        const res  = await fetch(`${API}/api/login`, {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            body:    JSON.stringify({ username: user, password: pass })
        });
        const data = await res.json();
        if (!res.ok) { showAuthError(data.error || 'ACCESS DENIED'); return; }

        authToken   = data.token;
        currentUser = user;
        currentRole = data.role;

        console.log('[LOGIN] Success. Token set. User:', currentUser, 'Role:', currentRole);

        document.getElementById('auth-section').classList.add('hidden');
        document.getElementById('chat-section').classList.remove('hidden');
        document.getElementById('current-user').textContent = user.toUpperCase();
        document.getElementById('current-role').textContent = currentRole.toUpperCase();
        document.getElementById('user-avatar').textContent  = user.slice(0, 2).toUpperCase();

        applyRoleUI(currentRole);
        showSystemMsg(`WELCOME, OPERATOR ${user.toUpperCase()}`);
        await switchCell('cell_alpha', document.querySelector('.cell-btn[data-cell="cell_alpha"]'));
        startPolling();

    } catch (err) {
        console.error('[LOGIN] Exception:', err);
        showAuthError('SERVER UNREACHABLE — IS BACKEND RUNNING?');
    } finally {
        btn.textContent = 'Login';
        btn.disabled = false;
    }
}

async function register() {
    const user = document.getElementById('username').value.trim();
    const pass = document.getElementById('password').value.trim();
    if (!user || !pass) { showAuthError('USERNAME AND PASSWORD REQUIRED'); return; }

    const btn = document.querySelector('.btn-login-main');
    btn.textContent = 'REGISTERING…';
    btn.disabled = true;

    try {
        const res  = await fetch(`${API}/api/register`, {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            body:    JSON.stringify({ username: user, password: pass })
        });
        const data = await res.json();
        if (!res.ok) {
            showAuthError(data.error || 'REGISTRATION FAILED');
        } else {
            showAuthError('REGISTERED. NOW LOGIN.', true);
            document.getElementById('password').value = '';
        }
    } catch (err) {
        console.error('[REGISTER] Exception:', err);
        showAuthError('SERVER UNREACHABLE — IS BACKEND RUNNING?');
    } finally {
        btn.textContent = 'Login';
        btn.disabled = false;
    }
}

function applyRoleUI(role) {
    const roleColors = { Visitor:'#748B91', Member:'#4CAF50', Leader:'#2196F3', Admin:'#FF8C00' };
    document.getElementById('current-role').style.color = roleColors[role] || '#748B91';
    if (role === 'Visitor') {
        document.getElementById('composer-container').style.display = 'none';
        showSystemMsg('READ-ONLY ACCESS — VISITOR CLEARANCE');
    }
    if (role === 'Admin') {
        document.getElementById('admin-panel').classList.remove('hidden');
    }
}

async function switchCell(cellId, element) {
    currentCell = cellId;
    document.querySelectorAll('.cell-btn').forEach(b => b.classList.remove('active'));
    if (element) element.classList.add('active');
    const label = cellId.replace('_', ' ').toUpperCase();
    document.getElementById('active-cell-name').textContent = label;
    showSystemMsg(`SWITCHING TO ${label}`);
    await loadMessages();
}

async function selectCell(cellId, element) { await switchCell(cellId, element); }

async function loadMessages() {
    if (!authToken) {
        console.warn('[POLL] authToken is null — skipping fetch');
        return;
    }

    try {
        console.log('[POLL] Fetching messages for', currentCell);
        const res = await fetch(`${API}/api/messages/${currentCell}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        console.log('[POLL] Response status:', res.status);

        if (res.status === 401) {
            console.error('[POLL] Got 401 — session expired');
            stopPolling();
            showSystemMsg('SESSION EXPIRED — LOGGING OUT IN 3s');
            setTimeout(() => {
                authToken = null;
                document.getElementById('chat-section').classList.add('hidden');
                document.getElementById('auth-section').classList.remove('hidden');
                showLogin();
                showAuthError('SESSION EXPIRED — RECONNECT');
            }, 3000);
            return;
        }

        if (!res.ok) {
            console.warn('[POLL] Non-OK status:', res.status, '— staying logged in');
            return;
        }

        const data = await res.json();
        console.log('[POLL] Got', data.messages.length, 'messages');
        renderMessages(data.messages || []);

    } catch (err) {
        console.error('[POLL] Network exception:', err);
    }
}

function renderMessages(messages) {
    const feed = document.getElementById('messages-display');
    feed.innerHTML = '';

    if (messages.length === 0) {
        const empty = document.createElement('div');
        empty.className = 'no-messages';
        empty.textContent = '// NO TRANSMISSIONS IN THIS CELL //';
        feed.appendChild(empty);
        return;
    }

    messages.forEach(msg => {
        const wrapper   = document.createElement('div');
        const isMine    = msg.sender === currentUser;
        wrapper.className = `msg-wrapper ${isMine ? 'mine' : 'theirs'}`;

        const meta      = document.createElement('div');
        meta.className  = 'msg-meta';
        const ts        = new Date(msg.timestamp * 1000);
        const time      = ts.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        meta.textContent = isMine ? time : `${msg.sender} · ${time}`;

        const bubble    = document.createElement('div');
        bubble.className = 'msg-bubble';
        bubble.textContent = msg.content;

        wrapper.appendChild(meta);
        wrapper.appendChild(bubble);

        if (msg.expiry > 0) {
            const ttlEl     = document.createElement('div');
            ttlEl.className = 'msg-ttl';
            const remaining = Math.max(0, msg.expiry - utcNow());
            const mins      = Math.floor(remaining / 60);
            const secs      = remaining % 60;
            ttlEl.textContent = remaining > 0
                ? `⏱ ${mins > 0 ? mins + 'm ' : ''}${secs}s`
                : '⏱ EXPIRED';
            wrapper.appendChild(ttlEl);
        }

        feed.appendChild(wrapper);
    });

    feed.scrollTop = feed.scrollHeight;
}

async function sendMessage() {
    const input   = document.getElementById('message-content');
    const content = input.value.trim();

    console.log('[SEND] Attempting send. authToken is:', authToken ? 'SET' : 'NULL');

    if (!content || !authToken) {
        console.warn('[SEND] Blocked — content empty or no token');
        return;
    }

    const ttlInput = document.getElementById('ttl-input');
    const ttl      = ttlInput ? parseInt(ttlInput.value) || 0 : 0;

    const btn = document.getElementById('send-btn');
    btn.disabled = true;

    try {
        console.log('[SEND] POSTing to /api/messages/send');
        const res = await fetch(`${API}/api/messages/send`, {
            method:  'POST',
            headers: {
                'Content-Type':  'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ cell_id: currentCell, content, ttl })
        });

        console.log('[SEND] Response status:', res.status);

        if (res.status === 401) {
            console.error('[SEND] 401 on send — session expired');
            showSystemMsg('SESSION EXPIRED — PLEASE LOG IN AGAIN');
            setTimeout(() => {
                authToken = null;
                document.getElementById('chat-section').classList.add('hidden');
                document.getElementById('auth-section').classList.remove('hidden');
                showLogin();
            }, 2000);
            return;
        }
        if (res.status === 403) { showSystemMsg('TRANSMISSION DENIED — CLEARANCE INSUFFICIENT'); return; }
        if (res.status === 429) { showSystemMsg('RATE LIMITED — SLOW DOWN'); return; }

        if (!res.ok) {
            let errMsg = 'TRANSMISSION FAILED';
            try { const d = await res.json(); errMsg = d.error || errMsg; } catch {}
            console.error('[SEND] Failed:', errMsg);
            showSystemMsg(errMsg);
            return;
        }

        console.log('[SEND] Success — loading messages');
        input.value = '';
        if (ttlInput) ttlInput.value = '';
        await loadMessages();

    } catch (err) {
        console.error('[SEND] Exception:', err);
        showSystemMsg('TRANSMISSION ERROR — CHECK CONNECTION');
    } finally {
        btn.disabled = false;
    }
}

function openAdminModal() {
    document.getElementById('admin-modal').classList.remove('hidden');
    document.getElementById('admin-target-user').focus();
    document.getElementById('admin-feedback').classList.add('hidden');
    document.querySelectorAll('.role-option').forEach(b => b.classList.remove('selected'));
    selectedRole = null;
}

function closeAdminModal() {
    document.getElementById('admin-modal').classList.add('hidden');
    document.getElementById('admin-target-user').value = '';
    selectedRole = null;
}

function selectRole(btn) {
    document.querySelectorAll('.role-option').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    selectedRole = btn.dataset.role;
}

async function promoteUser() {
    const targetUser = document.getElementById('admin-target-user').value.trim();
    if (!targetUser)   { showAdminFeedback('TARGET OPERATOR REQUIRED', false); return; }
    if (!selectedRole) { showAdminFeedback('SELECT A CLEARANCE LEVEL',  false); return; }

    const btn = document.querySelector('.btn-promote');
    btn.textContent = 'EXECUTING…';
    btn.disabled    = true;

    try {
        const res  = await fetch(`${API}/api/admin/promote`, {
            method:  'POST',
            headers: {
                'Content-Type':  'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ username: targetUser, role: selectedRole })
        });
        const data = await res.json();
        if (!res.ok) {
            showAdminFeedback(data.error || 'PROMOTION FAILED', false);
        } else {
            showAdminFeedback(`${targetUser.toUpperCase()} → ${selectedRole.toUpperCase()} ✓`, true);
            showSystemMsg(`ROLE UPDATED: ${targetUser.toUpperCase()} IS NOW ${selectedRole.toUpperCase()}`);
        }
    } catch {
        showAdminFeedback('SERVER UNREACHABLE', false);
    } finally {
        btn.textContent = 'EXECUTE PROMOTION';
        btn.disabled    = false;
    }
}

function showAdminFeedback(text, isSuccess) {
    const el = document.getElementById('admin-feedback');
    el.textContent = text;
    el.className   = `admin-feedback ${isSuccess ? 'success' : 'error'}`;
    el.classList.remove('hidden');
}

function startPolling() {
    stopPolling();
    pollTimer = setInterval(loadMessages, 5000);
}

function stopPolling() {
    if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
}

function logout() {
    stopPolling();
    authToken = currentUser = currentRole = null;
    location.reload();
}

function showSystemMsg(text) {
    const box = document.getElementById('system-messages');
    box.textContent = text;
    box.style.display = 'block';
    clearTimeout(box._timer);
    box._timer = setTimeout(() => { box.style.display = 'none'; }, 4000);
}

function showAuthError(text, isSuccess = false) {
    let el = document.getElementById('auth-error');
    if (!el) {
        el = document.createElement('p');
        el.id = 'auth-error';
        el.style.cssText = 'margin-top:14px;font-size:0.75rem;letter-spacing:2px;';
        document.querySelector('.minimal-login-card').appendChild(el);
    }
    el.textContent = text;
    el.style.color  = isSuccess ? '#4CAF50' : '#FF6B6B';
}

function clearAuthError() {
    const el = document.getElementById('auth-error');
    if (el) el.textContent = '';
}

document.addEventListener('DOMContentLoaded', () => {
    const ta = document.getElementById('message-content');
    if (ta) {
        ta.addEventListener('keydown', e => {
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
        });
    }
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') closeAdminModal();
    });
    document.getElementById('admin-modal').addEventListener('click', function(e) {
        if (e.target === this) closeAdminModal();
    });
});