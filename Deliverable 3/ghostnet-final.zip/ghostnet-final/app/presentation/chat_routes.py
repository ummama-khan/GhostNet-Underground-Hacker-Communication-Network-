from flask import Blueprint, request, jsonify
import datetime
import calendar
import os
import html
import logging
from ..storage.database import load_data, save_data, MESSAGES_FILE
from ..application.security import token_required, require_role

chat_bp = Blueprint('chat', __name__)


def utc_now_timestamp():
    """Pure UTC unix integer. Ignores Windows system timezone."""
    return calendar.timegm(datetime.datetime.utcnow().timetuple())


@chat_bp.route('/messages/send', methods=['POST'])
@token_required
@require_role(['Member', 'Leader', 'Admin'])
def send_message(current_user):
    data        = request.json
    cell_id     = data.get('cell_id')
    raw_content = data.get('content')
    ttl_minutes = data.get('ttl', 0)

    if not cell_id or not raw_content:
        return jsonify({"error": "Missing cell_id or content"}), 400

    try:
        ttl_minutes = int(ttl_minutes)
    except (ValueError, TypeError):
        ttl_minutes = 0

    safe_content = html.escape(raw_content)

    messages = load_data(MESSAGES_FILE)
    if cell_id not in messages["cells"]:
        messages["cells"][cell_id] = []

    now = utc_now_timestamp()

    if ttl_minutes > 0:
        expiry_dt   = datetime.datetime.utcnow() + datetime.timedelta(minutes=ttl_minutes)
        expiry_time = calendar.timegm(expiry_dt.timetuple())
    else:
        expiry_time = 0

    msg_obj = {
        "id":        os.urandom(8).hex(),
        "sender":    current_user['username'],
        "content":   safe_content,
        "timestamp": now,
        "expiry":    expiry_time
    }

    messages["cells"][cell_id].append(msg_obj)
    save_data(MESSAGES_FILE, messages)

    logging.info(f"MESSAGE SENT: {current_user['username']} posted to {cell_id}")
    return jsonify({"message": "Message sent securely!"})


@chat_bp.route('/messages/<cell_id>', methods=['GET'])
@token_required
def get_messages(current_user, cell_id):
    messages = load_data(MESSAGES_FILE)

    if cell_id not in messages["cells"]:
        return jsonify({"messages": []})

    cell_msgs    = messages["cells"][cell_id]
    current_time = utc_now_timestamp()

    active_messages = []
    for msg in cell_msgs:
        try:
            expiry = int(msg.get('expiry', 0))
        except (ValueError, TypeError):
            expiry = 0

        if expiry == 0 or expiry > current_time:
            msg['timestamp'] = int(float(msg.get('timestamp', current_time)))
            msg['expiry']    = expiry
            active_messages.append(msg)

    return jsonify({"messages": active_messages})